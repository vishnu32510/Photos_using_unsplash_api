

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class Splash extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Lottie.asset(
        'assets/lottie_file.json',
        repeat: false,
        reverse: false,
        animate: false,
      ),
    );
  }
}

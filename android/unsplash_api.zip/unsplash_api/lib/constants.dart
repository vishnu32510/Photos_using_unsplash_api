

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

String baseurl = 'https://api.unsplash.com/';
String photosurl = 'photos';
String searchurl = 'search/photos';
//

String clientid = '/?client_id=4flU2VputqN2M8QwJI5jWaI4KyIYAbYKbsXKatwwy7U';

Color appbarcolor = Colors.grey[900];
Color backgroundcolor = Colors.black;



int qualityurl;